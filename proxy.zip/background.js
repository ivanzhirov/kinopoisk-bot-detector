var arr1 = [{
        scheme: "http",
        host: "168.91.96.36",
        port: 27257
      },{
        scheme: "http",
        host: "168.91.97.15",
        port: 27257
      },{
        scheme: "http",
        host: “168.91.98.126",
        port: 27257
      },{
        scheme: "http",
        host: "168.91.99.131",
        port: 27257
      },{
        scheme: "http",
        host: "184.174.72.237",
        port: 27257
      },{
        scheme: "http",
        host: "184.174.73.190",
        port: 27257
      },{
        scheme: "http",
        host: "184.174.73.192",
        port: 27257
      },{
        scheme: "http",
        host: "184.174.74.138",
        port: 27257
      },{
        scheme: "http",
        host: "184.174.75.154”,
        port: 27257
      },{
        scheme: "http",
        host: "184.174.75.156",
        port: 27257
      },]

function randomChoice(arr) {
    return arr[Math.floor(arr.length * Math.random())];
}

var config = {
        mode: "fixed_servers",
        rules: {
          singleProxy: randomChoice(arr1),
          bypassList: ["foobar.com"]
        }
      };

chrome.proxy.settings.set({value: config, scope: "regular"}, function() {});

function callbackFn(details) {
    return {
        authCredentials: {
            username: "dariashpak",
            password: "2435qswd"
        }
    };
}

chrome.webRequest.onAuthRequired.addListener(
        callbackFn,
        {urls: ["<all_urls>"]},
        ['blocking']
);
